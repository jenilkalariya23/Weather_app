import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import SignUp from './components/SignUp';
import LoginForm from './components/LoginForm';
import WeatherCard from './components/WeatherCard';
import {Routes,Route} from 'react-router-dom'

function App() {
  return (
    <>
      <Header></Header>
      <Routes>
        <Route path='/' element={<SignUp></SignUp>}></Route>
        <Route path='/login' element={<LoginForm></LoginForm>}></Route>
        <Route path='/WeatherCard' element={<WeatherCard></WeatherCard>}></Route>

      </Routes>
    </>
  );
}

export default App;
