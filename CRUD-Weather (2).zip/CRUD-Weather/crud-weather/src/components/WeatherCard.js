import Button from 'react-bootstrap/Button';
import React, { useEffect, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom';
import Form from 'react-bootstrap/Form';


const WeatherCard = () => {

    const [city, setCity] = useState(null);
    const [search, setSearch] = useState("Ahmedabad");

    useEffect(() => {

        const fetchApi = async () => {
            const url = `https://api.openweathermap.org/data/2.5/weather?q=${search}&units=metric&appid=81909b3c7993b7bda5119aa8c186ccaf`
            const response = await fetch(url);
            const resJson = await response.json();
            setCity(resJson.main);
        }
        fetchApi();
    }, [search])

    const history = useNavigate();
    const userlogout = () => {
        localStorage.removeItem("userData")
        history("/");
    }

    const dataDelete = () => {
        localStorage.removeItem("apiData")
    }

    const [data] = useState([]);
    const fetchdata = (e) => {
        localStorage.setItem("apiData", JSON.stringify([...data, search, city]));
    }
    return (
        <>



            <div className="container mt-5">
                <section className='d-flex justify-content-between'>
                    <div className="left_data  p-3" style={{ width: "100%" }}>
                        <h3 className='text-center col-lg-6'>Weather Check</h3>
                        <Form>
                            <div className=''>
                                <div>
                                    <Form.Group className="mb-3 col-lg-3" controlId="formBasicName">
                                        <Form.Label>Search City</Form.Label>
                                        <Form.Control type={search} name="name" autocomplete="off" onChange={(event) => {
                                            setSearch(event.target.value)
                                        }} placeholder="Enter Name" />
                                    </Form.Group>
                                    {
                                        !city ? (
                                            <p>No Data Found</p>
                                        ) : (
                                            <div>
                                                <h2>{search}</h2>
                                                <h1>{city.temp} Cel</h1>
                                                <h3>min: {city.temp_min} cel | max: {city.temp_max} cel</h3>
                                             

                                                    
                                                <div className=''>
                                                    <Button variant="primary"  size="sm"onClick={fetchdata}>ADD</Button>{' '}
                                                    <Button variant="warning" size="sm" onClick={dataDelete}>Delete</Button>{' '}
                                                    <Button variant="danger" size="sm" onClick={userlogout}>LogOut</Button>{' '}
                                                </div>

                                            </div>
                                        )
                                    }
                                </div>
                            </div>
                        </Form>
                    </div>



                </section>
            </div>








            <table></table>
        </>
    )
}

export default WeatherCard
