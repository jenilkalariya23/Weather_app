import React, { useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import SignImg from './SignImg';
import { NavLink, useNavigate } from 'react-router-dom';

const LoginForm = () => {

    const history = useNavigate();

    const [inpval, setInpval] = useState({
       
        email: "",
        password: ""
    })
    console.log(inpval);

    const [data] = useState([]);

    const getdata = (e) => {

        const { value, name } = e.target;


        setInpval(() => {
            return {
                ...inpval,
                [name]: value
            }
        })
    }


    const addData = (e) => {
        e.preventDefault();

        const getuserArr = localStorage.getItem('userData');
        console.log(getuserArr);

        const {email, password } = inpval;

        if (email === "") {
            alert("Email Field is Requied");
        } else if (!email.includes('@')) {
            alert("Please enter valid email address");
        } else if (password === "") {
            alert("Password Field is Requied");
        } else if (password.length < 5) {
            alert("Password length greater five");
        } else {
            
            if(getuserArr && getuserArr.length){
                const userdata = JSON.parse(getuserArr);
                const userlogin = userdata.filter((el,k)=>{
                    return el.email === email && el.password === password
                });
                if(userlogin.length === 0 ){
                    alert("Invalid Details");
                }else{
                    console.log("User Login Success");
                    history("/WeatherCard");
                }

            }
        }

    }

  return (
    <>
    <div className="container mt-5">
        <section className='d-flex justify-content-between'>
            <div className="left_data  p-3" style={{ width: "100%" }}>
                <h3 className='text-center col-lg-6'>Sign In</h3>
                <Form>
                    
                    <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" name="email" onChange={getdata} placeholder="Enter email" autocomplete="off" />

                    </Form.Group>

                    <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" name="password" onChange={getdata} placeholder="Enter Password" />
                    </Form.Group>

                    <Button className="col-lg-6" onClick={addData} variant="primary" type="submit" style={{ backgroundColor: "rgb(67,185,127)" }}>
                        Submit
                    </Button>
                </Form>
                <p className='mt-3'>Create a new account ? <span><NavLink to={"/"}>Sign Up</NavLink></span></p>
            </div>

            <SignImg></SignImg>

        </section>
    </div>
</>
  )
}

export default LoginForm
