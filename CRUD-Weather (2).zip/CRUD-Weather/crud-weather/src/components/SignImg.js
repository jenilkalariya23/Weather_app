import React from 'react'

const SignImg = () => {
    return (
        <>
            <div className="right_data mt-5" style={{ width: "100%" }}>
                <div className="sign_img mt-5"></div>
                <img src="./sign.png" style={{ maxWidth: 400 }}></img>
            </div>
        </>
    )
}

export default SignImg
